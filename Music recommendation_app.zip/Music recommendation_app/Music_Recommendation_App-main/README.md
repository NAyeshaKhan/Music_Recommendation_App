# Music_Recommendation_App
Web-based application where a user can select a mood, and the site will return a genre and a list of songs from that genre

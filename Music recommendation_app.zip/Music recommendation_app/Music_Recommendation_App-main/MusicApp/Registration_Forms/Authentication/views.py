from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout


def home(request):
    return render(request, "Authentication/landing page.html")


def signup(request):
    if request.method == "POST":
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        age = request.POST['age']
        gender = request.POST['gender']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email Already Registered!!")
            return redirect('home')

        if pass1 != pass2:
            messages.error(request, "Passwords didn't matched!!")
            return redirect('home')

        myuser = User.objects.create_user(email, pass1)
        myuser.first_name = fname
        myuser.last_name = lname
        myuser.age = age
        myuser.gender = gender
        myuser.save()
        messages.success(request, "Your account has been successfully created.")

        return redirect('signin')


def signin(request):
    if request.method == 'POST':
        email = request.POST['email']
        pass1 = request.POST['pass1']

        user = authenticate(email=email, password=pass1)

        if user is not None:
            login(request, user)
            fname = user.first_name
            return render(request, "Authentication/dashboard.html")
        else:
            messages.error(request, "Wrong Credentials.")
            return redirect('home')

    return render(request, "Authentication/signin.html")


def signout(request):
    logout(request)
    messages.success(request, "Logged Out Successfully.")
    return redirect('home')
